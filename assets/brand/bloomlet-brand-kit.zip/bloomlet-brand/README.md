# Bloomlet brand kit

Everything here is drawn from the app itself: the same bud shape, colours and
fonts the app and website use. Made 25 November 2026.

## What's where

| Folder | What | Use it for |
|---|---|---|
| `01-logo/bud-mark/` | The bud on its own, SVG + PNG: rose (on light backgrounds), white (on rose), ink (one colour), green (only for "active now") | Small spaces, stickers, watermarks |
| `01-logo/wordmark/` | **The** Bloomlet logo: "bl" + bud + "omlet". Ink, rose and white | Anywhere the name appears |
| `01-logo/lockup/` | Bud beside "bloomlet", as in the website header. Ink and white | Headers, letterheads, slides |
| `02-app-icon/square/` | App icon, square, 16 to 1024 px | App Store (Apple rounds it), Google Play, anywhere that adds its own mask |
| `02-app-icon/rounded/` | App icon with rounded corners, transparent outside, 16 to 1024 px | Presentations, websites, documents, merch |
| `02-app-icon/circle/` | App icon as a circle, 16 to 1024 px | Round profile pictures, badges |
| `02-app-icon/ios/` | The exact 1024 icon built into the iPhone app | App Store Connect |
| `02-app-icon/android/` | The launcher icons and adaptive-icon foregrounds built into the Android app (background colour #A62B50, foreground inset 16%) | Play Console, Android builds |
| `02-app-icon/favicon/` | The website's browser-tab icons (rounded) and the iPhone home-screen icon | Websites |
| `03-colours/` | `palette.png` and `colours.txt` (hex + RGB + what each is for) | Designers, printers |
| `04-fonts/` | Which fonts, which weights, where to get them | Anyone making something new |
| `05-illustrations/bloom-stages/` | The bloom as it grows: bud, stem, leaves, opening, together. SVG + PNG | Ambassador posts, "growing" moments, stories |
| `06-social/` | Profile picture 1080, link preview 1200x630, Instagram story 1080x1920, banners for X (1500x500), LinkedIn (1584x396) and YouTube (2560x1440) | Social accounts |

Store screenshots live separately in `~/Downloads/bloomlet-store-images`.

## Rules

- **Name:** Bloomlet, capital B, in sentences. The wordmark is always lowercase.
- **On light backgrounds** use the ink or rose versions; **on rose or photos** use white.
- **Don't** stretch, rotate, recolour, outline or add shadows to the bud or wordmark.
- **Leave space** around the logo at least the height of the bud on every side.
- **Smallest sizes:** wordmark 80 px wide on screen (20 mm in print); bud 16 px.
- **Green** is only for "active now", never as a brand colour.
- **Backgrounds:** paper #F2F0EC is the brand's ground. The app has no dark theme.
